#!/usr/bin/env bash
echo "It's a trap"
exit
